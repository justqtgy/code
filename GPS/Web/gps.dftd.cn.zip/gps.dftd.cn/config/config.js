module.exports = {    
	user:'sa',
	password:'DSERVER@123',
	server : '120.24.68.95',
	database:'gserver_data'
	/*,
	options: {
        encrypt: false // Use this if you're on Windows Azure
    }
	*/
};
