﻿var gps_alarm = require('./routes/gps_alarm');

exports.init_route = function(app) {
    console.log('init_route begin');

    app.use('/gps_alarm', gps_alarm);

    console.log('init_route end');
}