function add_capacity_data(data) {
    /*
    var item = {};
    if (data.substr(0, 2) == '59') {
        var oil1 = data.substr(2, 4);
        item.oil1 = parseInt(oil1, 16);
        var oil2 = data.substr(6, 4);
        item.oil2 = parseInt(oil2, 16);
        item.gpstime = common.format_time(data.substr(12, 6), data.substr(18, 6));
        item.lng = data.substr(24, 8);
        item.lat = data.substr(34, 8);
        item.speed = data.substr(44, 3);
        item.direct = data.substr(47, 3);
        item.status = data.substr(50, 8);
        item.temp = data.substr(52, 2);
    }
    */
}