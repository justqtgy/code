module.exports = require("./lib/main")
module.exports.fix = false