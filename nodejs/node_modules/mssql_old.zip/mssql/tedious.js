module.exports = require('./lib/tedious.js')
